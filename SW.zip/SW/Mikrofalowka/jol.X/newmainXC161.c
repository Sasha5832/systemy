/*
 * File:   newmainXC161.c
 * Author: local
 *
 * Created on May 29, 2024, 5:34 PM
 */


#include "xc.h"

int main(void) {
    return 0;
}
