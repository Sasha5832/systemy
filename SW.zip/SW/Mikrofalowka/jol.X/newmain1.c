/* 
 * File:   newmain1.c
 * Author: local
 *
 * Created on May 29, 2024, 5:35 PM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

